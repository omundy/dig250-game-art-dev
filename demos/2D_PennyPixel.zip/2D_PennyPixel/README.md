
This is a modified version of the "Penny Pixel" game from the [Intermedia 2D Game Creation](https://unity3d.com/learn/tutorials/topics/2d-game-creation/intro-and-session-goals?playlist=17093) Unity tutorial

