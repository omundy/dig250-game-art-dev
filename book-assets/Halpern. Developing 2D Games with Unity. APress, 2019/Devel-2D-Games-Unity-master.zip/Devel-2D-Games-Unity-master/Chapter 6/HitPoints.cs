using UnityEngine;

[CreateAssetMenu(menuName = "HitPoints")]
public class HitPoints : ScriptableObject
{
    public float value;
}