using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour {
    public Text qtyText;
}