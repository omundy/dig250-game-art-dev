using UnityEngine;

public class Consumable : MonoBehaviour {

    public Item item;
}
