using UnityEngine;

public abstract class Character : MonoBehaviour {

    public int hitPoints;
    public int maxHitPoints;
}