Thanks for downloading this package from player26.com

You can use this free package in any project, personal or commercial. There's no need to ask permission before using these. However, giving attribution is required (see full detail in "License.txt").

You are allowed to redistribuite this work, but it must be unchanged. As such, you need to include this Readme file along with the Licence file.

We offer also a Pro version of our assets, which they are royalty free (so you can modify and use without attribuition).

If you use these in some of your projects, let us hear what amazing things you have created. you can email us at contact@player26.com


You can attribuite by placing the following line in a visible place in your work:
"Lauren S. Ferro (player26.com)"